import React, { useEffect, useState } from "react";
import TodoList from "./TodoList";
import AddTodo from "./AddTodo";

const App = () => {
  // some constant and global varibles and useState
  const [users, setUsers] = useState([]);
  const baseUrl = "https://todo-backend-akrz.onrender.com/todos";

  // useEffect for continous fetching api on component
  useEffect(() => {
    fetchData();
  }, []);

  // fetching data arrow function
  const fetchData = async () => {
    await fetch(baseUrl)
      .then((res) => res.json())
      .then((data) => setUsers(data.allTodos))
      .catch((err) => {
        console.log(err);
      });
  };

  // add new todo
  const onAdd = async (newTodo) => {
    await fetch(baseUrl, {
      method: "POST",
      body: JSON.stringify({
        title: newTodo,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => {
        if (response.status !== 201) {
          return;
        } else {
          return response.json();
        }
      })
      .then((data) => {
        setUsers((users) => [...users, data]);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // delelte todo
  const onDelete = async (id) => {
    await fetch(baseUrl + `/${id}`, {
      method: "DELETE",
    })
      .then((response) => {
        if (response.status !== 200) {
          return;
        } else {
          setUsers(
            users.filter((user) => {
              return user._id !== id;
            })
          );
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // function to handle edit dummy api
  const handleEditTodos = async (editvalue, id) => {
    await fetch(baseUrl + `/${id}`, {
      method: "PUT",
      body: JSON.stringify({
        id: id,
        title: editvalue,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setUsers((users) => [...users, data]);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // switch check isDone or not
  const switchComplete = async (id) => {
    await fetch(baseUrl + `/${id}`, {
      method: "PUT",
      body: JSON.stringify({
        id: id,
        completed: !users.find((user) => user._id === id).completed,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((response) => response.json())
      .then(() => {
        setUsers(
          users.map((user) =>
            user._id === id ? { ...user, completed: !user.completed } : user
          )
        );
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // print userss on console
  // console.log(users)
  return (
    <div className="App">
      <br />
      <AddTodo onAdd={onAdd} />
      {users.map((user) => (
        <TodoList
          id={user._id}
          key={user._id}
          title={user.title}
          completed={user.completed}
          onDelete={onDelete}
          handleEditTodos={handleEditTodos}
          checkComplete={switchComplete}
        />
      ))}
    </div>
  );
};

export default App;
